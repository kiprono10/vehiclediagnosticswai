import pandas as pd

df = pd.read_csv("cleaned_file.csv")
print("Number of rows in dataset:", len(df))
print(df.head())  # Check first few rows
