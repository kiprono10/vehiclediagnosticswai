import pandas as pd
import numpy as np
import pickle
from flask import Flask, request, render_template
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestRegressor

# Load dataset
df = pd.read_csv("cleaned_file.csv")

# Print dataset info before cleaning
print("Dataset shape before cleaning:", df.shape)
print("Missing values before cleaning:\n", df.isnull().sum())

# Handle missing values
numeric_cols = df.select_dtypes(include=['number']).columns  # Get numeric columns
categorical_cols = df.select_dtypes(include=['object']).columns  # Get categorical columns

df[numeric_cols] = df[numeric_cols].fillna(df[numeric_cols].mean())  # Fill numeric columns with mean
df[categorical_cols] = df[categorical_cols].fillna("Unknown")  # Fill categorical columns with "Unknown"

# Print dataset shape after filling missing values
print("Dataset shape after cleaning:", df.shape)

# Ensure enough samples for train-test split
if df.shape[0] < 10:
    raise ValueError("Dataset is still too small! Please check your CSV file.")

# Encode categorical variables
le_make = LabelEncoder()
df['make'] = le_make.fit_transform(df['make'])
le_model = LabelEncoder()
df['model'] = le_model.fit_transform(df['model'])
le_trany = LabelEncoder()
df['trany'] = le_trany.fit_transform(df['trany'])

# Define input features and target variables
X = df[['make', 'model', 'year', 'trany', 'displacement']]
y1 = df['co2_Tail_pipe_G/km']
y2 = df['your_Save']
y3 = df['your_Spending']

# Adjust test size dynamically
test_size = 0.05 if len(df) < 100 else 0.1

# Train models
X_train, X_test, y1_train, y1_test = train_test_split(X, y1, test_size=test_size, random_state=42)
X_train, X_test, y2_train, y2_test = train_test_split(X, y2, test_size=test_size, random_state=42)
X_train, X_test, y3_train, y3_test = train_test_split(X, y3, test_size=test_size, random_state=42)

model_co2 = RandomForestRegressor()
model_co2.fit(X_train, y1_train)

model_save = RandomForestRegressor()
model_save.fit(X_train, y2_train)

model_spend = RandomForestRegressor()
model_spend.fit(X_train, y3_train)

# Save models
pickle.dump(model_co2, open("model_co2.pkl", "wb"))
pickle.dump(model_save, open("model_save.pkl", "wb"))
pickle.dump(model_spend, open("model_spend.pkl", "wb"))
pickle.dump(le_make, open("le_make.pkl", "wb"))
pickle.dump(le_model, open("le_model.pkl", "wb"))
pickle.dump(le_trany, open("le_trany.pkl", "wb"))

# Flask App
app = Flask(__name__)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/predict', methods=['POST'])
def predict():
    make = request.form['make']
    model = request.form['model']
    year = int(request.form['year'])
    trany = request.form['trany']
    displacement = float(request.form['displacement'])
    
    # Load encoders and models
    le_make = pickle.load(open("le_make.pkl", "rb"))
    le_model = pickle.load(open("le_model.pkl", "rb"))
    le_trany = pickle.load(open("le_trany.pkl", "rb"))
    model_co2 = pickle.load(open("model_co2.pkl", "rb"))
    model_save = pickle.load(open("model_save.pkl", "rb"))
    model_spend = pickle.load(open("model_spend.pkl", "rb"))
    
    # Handle unseen labels
    if make not in le_make.classes_:
        le_make.classes_ = np.append(le_make.classes_, make)
    if model not in le_model.classes_:
        le_model.classes_ = np.append(le_model.classes_, model)
    if trany not in le_trany.classes_:
        le_trany.classes_ = np.append(le_trany.classes_, trany)

    # Encode inputs
    make_enc = le_make.transform([make])[0]
    model_enc = le_model.transform([model])[0]
    trany_enc = le_trany.transform([trany])[0]
    
    # Make predictions
    input_data = np.array([[make_enc, model_enc, year, trany_enc, displacement]])
    co2_pred = model_co2.predict(input_data)[0]
    save_pred = model_save.predict(input_data)[0]
    spend_pred = model_spend.predict(input_data)[0]
    
    return render_template("index.html", co2=co2_pred, save=save_pred, spend=spend_pred)

if __name__ == '__main__':
    app.run(debug=True)
